# Kasus Kelompok D: Monitoring Error
setpoint = 50
data_inti = [50, 49, 47, 45, 43, 
             52, 54, 57, 51, 48, 
             46, 44, 53, 55, 42]

data_tambahan = [51.5, 47.5, 45.5, 55.5, 60]

data_output = data_inti + data_tambahan

# hitung error
# status error
# hitung rata rata

def hitung_error(setpoint, output) :
    return abs(setpoint - output)

def status_error(error):
    if error <= 2:
        return "STABIL"
    elif error <= 5:
        return "WARNING"
    else:
        return "TIDAK STABIL"

def rata_rata(data_error):
    total = 0
    for error in data_error:
        total +=error
    return total / len(data_error)

def hitung_kategori(data_error):
    stabil = 0
    warning = 0
    tidak_stabil = 0
    for error in data_error:
        status = status_error(error)
        if status == "STABIL":
            stabil += 1
        elif status == "WARNING":
            warning += 1
        else:
            tidak_stabil += 1
    return stabil, warning, tidak_stabil    


print("=== ERROR MONITORING SYSTEM ===")
print("Setpoint:", setpoint)

data_error = []

for i in range(len(data_output)):
    output = data_output[i]
    error = hitung_error(setpoint, output)
    status = status_error(error)
    data_error.append(error)
    print(i + 1, ".", output, "-> Error:", round(error, 2), "->", status)

stabil, warning, tidak_stabil = hitung_kategori(data_error)
average = rata_rata(data_error)

print()
print("=== RINGKASAN ===")
print("Total Data:", len(data_output))
print("STABIL:", stabil)
print("WARNING:", warning)
print("TIDAK STABIL:", tidak_stabil)
print("Rata-rata Error:", round(average, 2))
print("Minimum Error:", round(min(data_error), 2))
print("Maksimum Error:", round(max(data_error), 2))